/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App;


import Modelo.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Cristian
 */
public class Crud {
    private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private Clientes cliente = new Clientes();
    private Date fechaActual = new Date();
    private ProductoControlMet proConMet = new ProductoControlMet();
    private AntibioticosMet antMet = new AntibioticosMet();
    private Facturas factura = new Facturas();
    private ClienteMet cliMet = new ClienteMet();
    private long Valortotal = 0;
       
    public void comprarProductos() throws IOException {
        String registroICA = "", NombreDelProducto = "", Nombre = "", cedula = "", opcion = "", Respuesta = "s";
        long RegistroICA = 0, Cedula = 0;
        int Opcion = 0;        
        System.out.println("====== CATALOGO DE TIENDA AGRICOLA ======\n");
        if(!proConMet.listaProductosDeControlVacia())
            proConMet.listarProductosDeControl();
        if(!antMet.listaAntibioticosVacia())
            antMet.listarAntibioticos();
        do {
            System.out.println("====== MENU PARA COMPRAR ======\n");
            System.out.println("1.Digite Registro ICA para agregar productos de control a la factura");
            System.out.println("2.Digite nombre del producto para agregar antibioticos a la factura");
            System.out.println("\nDigite Opcion: ");
            opcion = this.reader.readLine();
            Opcion = Integer.parseInt(opcion);           
            switch(Opcion) {
                case 1:
                    if(!proConMet.listaProductosDeControlVacia()) {
                        System.out.println("Digite Registro ICA:");
                        registroICA = this.reader.readLine();
                        RegistroICA = Long.parseLong(registroICA);
                        proConMet.buscarProductosDeControlPorRegistroICA(RegistroICA);
                        System.out.println("Desea agregar mas productos? [S/N]: ");
                        Respuesta = this.reader.readLine();
                    } else    
                        System.out.println("¡ATENCION! No hay productos de control en el catalago.\n");
                    break;
                case 2:
                    if (!antMet.listaAntibioticosVacia()) {
                        System.out.println("Digite nombre del producto:");
                        NombreDelProducto = this.reader.readLine();                  
                        antMet.buscarAntibioticosPorNombreDelProducto(NombreDelProducto);
                        System.out.println("Desea agregar mas productos? [S/N]: ");
                        Respuesta = this.reader.readLine(); 
                    } else 
                        System.out.println("¡ATENCION! No hay antibioticos en el catalago.\n");
                    break;    
                default:
                      System.out.println("¡ATENCION! Digite opcion dentro de menu para comprar.\n"); 
            }                       
        } while (Respuesta.equalsIgnoreCase("s"));
        if (!this.factura.getProductos().isEmpty() || !this.factura.getAntibioticos().isEmpty()) {
            System.out.println("====== COMPRAR PRODUCTOS AGREGADOS ======\n");
            System.out.println("Esta seguro de comprar productos agregados?.");
            System.out.println("1.Comprar");
            System.out.println("2.No Comprar");
            System.out.println("\nDigite Opcion: ");
            opcion = this.reader.readLine();
            Opcion = Integer.parseInt(opcion);
            switch (Opcion) {
                case 1:
                    System.out.println("====== PROCESO DE COMPRA ======\n");
                    System.out.println("Digite nombre del cliente: ");
                    Nombre = this.reader.readLine();
                    System.out.println("Digite cedula del cliente: ");
                    cedula = this.reader.readLine();
                    Cedula = Long.parseLong(cedula);
                    this.factura.setFecha(this.fechaActual);
                    if(cliMet.clienteExiste(Cedula)) {
                        for (Clientes cliente : this.cliMet.clientes) {
                            if (cliente.getCedula() == Cedula) {       
                                cliente.aggFacturas(this.factura);
                                break;
                            }  
                        }
                    } else {
                        this.cliente = new Clientes(Nombre, Cedula, this.factura);
                        this.cliMet.clientes.add(this.cliente);
                    }
                    mostrarFactura(this.factura);
                    break;
                case 2:
                    System.out.println("¡FACTURA! cancelada.");
                    break;
                default:
                    System.out.println("¡ATENCION! Digite opcion dentro de comprar productos agregados.\n");
            }
            this.factura = new Facturas();
            this.Valortotal = 0;
        }     
    }
   
    private void mostrarFactura(Facturas factura) {
        System.out.println("====== FACTURA ========\n");
        System.out.println("Fecha: "+factura.getFecha());
        System.out.println("Productos agregados: \n");
        for (ProductosDeControl producto : factura.getProductos()) 
            proConMet.mostrarProductosDeControl(producto);
        for (Antibioticos antibiotico : factura.getAntibioticos())
            antMet.mostrarAntibioticos(antibiotico);
        System.out.println("Valor total: "+factura.getValorTotal()+"\n");      
    }
    
    
    //ProductosDeControl

    
    
    
    //Antibioticos
    
    
    
    //CLIENTE
    
}
