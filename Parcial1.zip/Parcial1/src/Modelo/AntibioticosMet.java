/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class AntibioticosMet {
    private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private long Valortotal = 0;
    private Antibioticos antibiotico = new Antibioticos();
    private List<Antibioticos> antibioticos = new ArrayList<>();
    private Facturas factura = new Facturas();
    
    public void agregarAntibioticos() throws IOException{
        int i = 1;
        String NombreDelProducto = "", Dosis = "", TipoDeAnimal = "", precio = "", Respuesta = "";
        long Precio = 0;
        do {           
            System.out.println("====== AGREGAR ANTIBIOTICOS ======\n");
            System.out.println("====== ANTIBIOTICOS PARA BOVINOS Y PORCINOS[" + i + "] ======\n");
            System.out.println("Digite el nombre del producto: ");
            NombreDelProducto = this.reader.readLine();
            System.out.println("Digite dosis [Entre 400Kg y 600Kg]: ");
            Dosis = this.reader.readLine(); 
            System.out.println("Digite el tipo de animal [Bovinos, caprinos o porcinos]: ");
            TipoDeAnimal = this.reader.readLine();
            System.out.println("Digite el valor del producto: ");
            precio = this.reader.readLine();
            Precio = Long.parseLong(precio);
            this.antibiotico = new Antibioticos(NombreDelProducto, Dosis, TipoDeAnimal, Precio);
            this.antibioticos.add(this.antibiotico);         
            System.out.println("\nDesea ingresar mas antibioticos? [S/N]: ");
            Respuesta = this.reader.readLine();
            i++;            
        } while (Respuesta.equalsIgnoreCase("s")); 
    }
    
    public void listarAntibioticos(){
        System.out.println("====== ANTIBIOTICOS ======\n");
        for (Antibioticos antibiotico: this.antibioticos) 
            mostrarAntibioticos(antibiotico);   
    }
    
    public void mostrarAntibioticos(Antibioticos antibiotico) { 
        System.out.println("Nombre del antibiotico: " + antibiotico.getNombreDelProducto());
        System.out.println("Dosis: " + antibiotico.getDosis());
        System.out.println("Tipo de animal: " + antibiotico.getTipoDeAnimal());
        System.out.println("Valor del producto: " + antibiotico.getPrecio()+"\n");
    }
    
    public void buscarAntibioticosPorNombreDelProducto(String NombreDelProducto) {      
        for (Antibioticos antibiotico: this.antibioticos) {
            if (antibiotico.getNombreDelProducto().equals(NombreDelProducto)) {
                this.Valortotal = this.Valortotal + antibiotico.getPrecio();
                this.factura.setValorTotal(Valortotal);
                this.factura.aggAntibioticos(antibiotico);
                System.out.println("¡FACTURA! Se agrego producto con exito.");
                return;
            }      
        }
        System.out.println("¡ATENCION! Antibiotico no existe.\n");
    }
    
    public boolean listaAntibioticosVacia() {
        return this.antibioticos.isEmpty();
    }
}
