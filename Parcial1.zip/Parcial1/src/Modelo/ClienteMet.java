/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class ClienteMet {
    
    private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    public static List<Clientes> clientes = new ArrayList<>();
    
    public boolean clienteExiste(long Cedula){
        for (Clientes cliente : this.clientes) {
            if(cliente.getCedula() == Cedula) 
                return true;   
        }
        return false;
    }
    
    public void buscarHistorialCliente() throws IOException {
        String cedula = "";
        long Cedula = 0;
        System.out.println("====== BUSCAR HISTORIAL DEL CLIENTE ========\n");
        System.out.println("Digite Cedula de Cliente: ");
        cedula = this.reader.readLine();
        Cedula = Long.parseLong(cedula);
        for (Clientes cliente: this.clientes) {
            if(cliente.getCedula()== Cedula) {
                mostrarHistorialCliente(cliente);
                return;
            }       
        }
        System.out.println("¡ATENCION! Cliente no existe.\n");  
    }

    public void mostrarHistorialCliente(Clientes cliente) {
        System.out.println("======= HISTORIAL DE CLIENTE ========\n");
        System.out.println("Nombre: " + cliente.getNombre());
        System.out.println("Cedula: " + cliente.getCedula() + "\n");
        System.out.println("Facturas asociadas al cliente: \n");
        for (Facturas factura : cliente.getFacturas()) {
            System.out.println(factura);
            //factura.toString();
        }
    }
}
