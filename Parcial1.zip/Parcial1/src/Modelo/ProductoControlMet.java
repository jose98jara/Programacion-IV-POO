/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class ProductoControlMet {
    private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private List<ProductosDeControl> productos = new ArrayList<>();
    private long Valortotal = 0;
    private Facturas factura = new Facturas();
    private ControlDeFertilizantes fertilizante = new ControlDeFertilizantes();
    private ControlDePlagas plaga = new ControlDePlagas();

    public void buscarProductosDeControlPorRegistroICA(long RegistroICA) {
        for (ProductosDeControl producto : this.productos) {
            if (producto.getRegistroICA() == RegistroICA) {
                this.Valortotal = this.Valortotal + producto.getValorDelproducto();
                this.factura.setValorTotal(Valortotal);
                this.factura.aggProductos(producto);
                System.out.println("¡FACTURA! Se agrego producto con exito.");
                return;
            }
        }
        System.out.println("¡ATENCION! Producto de control no existe.\n");
    }
    
    public void agregarProductosDeControl() throws IOException{
        int i = 1, j = 1, Opcion = 0;
        String registroICA = "", NombreDelProducto  = "", FrecuenciaDeAplicacion = "", valorDelProducto = "", FechaUltimaAplicacion = "", PeriodoDeCarencia = "", opcion = "", Respuesta = "s";
        long RegistroICA = 0, ValorDelProducto = 0;
        do {           
            System.out.println("====== AGREGAR PRODUCTOS DE CONTROL ======\n");
            System.out.println("1. Fertilizantes.");
            System.out.println("2. Control de plagas.\n");
            System.out.println("Opcion: ");
            opcion = this.reader.readLine();
            Opcion = Integer.parseInt(opcion);
            switch(Opcion) {
                case 1:
                    System.out.println("====== PRODUCTOS DE CONTROL FERTILIZANTE[" + i + "] ======\n");
                    System.out.println("Digite el registro ICA: ");
                    registroICA = this.reader.readLine();
                    RegistroICA = Long.parseLong(registroICA);
                    System.out.println("Digite nombre del producto: ");
                    NombreDelProducto = this.reader.readLine(); 
                    System.out.println("Digite la frecuencia de aplicacion: ");
                    FrecuenciaDeAplicacion = this.reader.readLine();
                    System.out.println("Digite el valor del producto: ");
                    valorDelProducto = this.reader.readLine();
                    ValorDelProducto = Long.parseLong(valorDelProducto);
                    System.out.println("Digite fecha de la ultima aplicacion del fertilizante: ");
                    FechaUltimaAplicacion = this.reader.readLine();
                    this.fertilizante = new ControlDeFertilizantes(FechaUltimaAplicacion, RegistroICA, NombreDelProducto, FrecuenciaDeAplicacion, ValorDelProducto);
                    this.productos.add(this.fertilizante);
                    System.out.println("\nDesea ingresar mas productos de control? [S/N]: ");
                    Respuesta = this.reader.readLine();
                    i++;
                    break;
                case 2:
                    System.out.println("====== PRODUCTOS DE CONTROL DE PLAGAS[" + j + "] ======\n");
                    System.out.println("Digite el registro ICA: ");
                    registroICA = this.reader.readLine();
                    RegistroICA = Long.parseLong(registroICA);
                    System.out.println("Digite nombre del producto: ");
                    NombreDelProducto = this.reader.readLine(); 
                    System.out.println("Digite la frecuencia de aplicacion: ");
                    FrecuenciaDeAplicacion = this.reader.readLine();
                    System.out.println("Digite el valor del producto: ");
                    valorDelProducto = this.reader.readLine();
                    ValorDelProducto = Long.parseLong(valorDelProducto);
                    System.out.println("Digite periodo de carencia del producto control de plaga: ");
                    PeriodoDeCarencia = this.reader.readLine();
                    this.plaga = new ControlDePlagas(PeriodoDeCarencia, RegistroICA, NombreDelProducto, FrecuenciaDeAplicacion, ValorDelProducto);
                    this.productos.add(this.plaga);
                    System.out.println("\nDesea ingresar mas productos de control? [S/N]: ");
                    Respuesta = this.reader.readLine();
                    j++;
                    break;
                default:
                    System.out.println("¡ATENCION! Digite opcion de agregar productos de control.\n"); 
            }  
        } while (Respuesta.equalsIgnoreCase("s")); 
    }
    
    public void mostrarProductosDeControl(ProductosDeControl producto) { 
        System.out.println("Registro ICA: " + producto.getRegistroICA());
        System.out.println("Nombre del producto control: " + producto.getNombreDelProducto());    
        System.out.println("Frecuencia de la aplicacion: " + producto.getFrecuenciaDeAplicacion());
        producto.detalle();
        System.out.println("Valor del producto: " + producto.getValorDelproducto()+"\n");
    }
    
    public void listarProductosDeControl(){
        System.out.println("====== PRODUCTOS DE CONTROL ======\n");
        for (ProductosDeControl producto : this.productos) 
            mostrarProductosDeControl(producto);  
    } 
    
    public boolean listaProductosDeControlVacia() {
        return this.productos.isEmpty();
    }
}
